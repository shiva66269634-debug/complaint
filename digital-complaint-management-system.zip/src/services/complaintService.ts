import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Complaint,
  ComplaintCategory,
  Department,
  Priority,
  ComplaintStatus,
  ComplaintHistory,
} from '../types';

export const COMPLAINT_CATEGORIES: ComplaintCategory[] = [
  'Infrastructure',
  'Electricity',
  'Water Supply',
  'Sanitation and Cleanliness',
  'Technical Issues',
  'Safety and Security',
  'Public Services',
  'Other',
];

export const DEPARTMENTS: Department[] = [
  'Infrastructure Department',
  'Electrical Department',
  'Water and Sanitation Department',
  'IT Support Department',
  'Security Department',
  'General Administration',
];

export const STATUS_LIST: ComplaintStatus[] = [
  'Submitted',
  'Pending',
  'In Progress',
  'Resolved',
  'Rejected',
];

export const PRIORITY_LIST: Priority[] = ['Low', 'Medium', 'High'];

// Map category to a default recommended department for intuitive UX
export const CATEGORY_DEPARTMENT_MAP: Record<ComplaintCategory, Department> = {
  Infrastructure: 'Infrastructure Department',
  Electricity: 'Electrical Department',
  'Water Supply': 'Water and Sanitation Department',
  'Sanitation and Cleanliness': 'Water and Sanitation Department',
  'Technical Issues': 'IT Support Department',
  'Safety and Security': 'Security Department',
  'Public Services': 'General Administration',
  Other: 'General Administration',
};

// Generate unique Complaint Number e.g. CMP-2026-48201
export function generateComplaintNumber(): string {
  const year = new Date().getFullYear();
  const randomNum = Math.floor(10000 + Math.random() * 90000);
  return `CMP-${year}-${randomNum}`;
}

export interface NewComplaintPayload {
  userId: string;
  userName: string;
  userEmail: string;
  title: string;
  category: ComplaintCategory;
  description: string;
  location: string;
  department: Department;
  priority?: Priority;
  attachmentUrl?: string;
}

export async function submitComplaint(payload: NewComplaintPayload): Promise<Complaint> {
  const complaintsCol = collection(db, 'complaints');
  const newDocRef = doc(complaintsCol);
  const complaintNumber = generateComplaintNumber();
  const now = new Date().toISOString();

  const newComplaint: Complaint = {
    id: newDocRef.id,
    complaintNumber,
    userId: payload.userId,
    userName: payload.userName,
    userEmail: payload.userEmail,
    title: payload.title.trim(),
    category: payload.category,
    description: payload.description.trim(),
    location: payload.location.trim(),
    department: payload.department,
    priority: payload.priority || 'Medium',
    status: 'Submitted',
    attachmentUrl: payload.attachmentUrl || '',
    adminRemarks: '',
    resolutionDetails: '',
    createdAt: now,
    updatedAt: now,
  };

  try {
    await setDoc(newDocRef, newComplaint);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `complaints/${newDocRef.id}`);
  }

  // Create initial audit log entry
  try {
    const historyCol = collection(db, 'complaints', newDocRef.id, 'history');
    const historyDocRef = doc(historyCol);
    const initialHistory: ComplaintHistory = {
      id: historyDocRef.id,
      complaintId: newDocRef.id,
      previousStatus: 'None',
      newStatus: 'Submitted',
      remarks: 'Complaint registered in the system.',
      changedBy: payload.userName || payload.userEmail,
      changedById: payload.userId,
      timestamp: now,
    };
    await setDoc(historyDocRef, initialHistory);
  } catch (err) {
    console.warn('Initial history log could not be written:', err);
  }

  return newComplaint;
}

// Subscribe to a user's complaints in real-time
export function subscribeToUserComplaints(
  userId: string,
  onSuccess: (complaints: Complaint[]) => void,
  onError: (error: Error) => void
) {
  const complaintsCol = collection(db, 'complaints');
  const q = query(complaintsCol, where('userId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const results: Complaint[] = [];
      snapshot.forEach((doc) => {
        results.push({ id: doc.id, ...(doc.data() as Omit<Complaint, 'id'>) });
      });
      // Sort in-memory to prevent complex composite index requirements
      results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onSuccess(results);
    },
    (error) => {
      onError(error);
      handleFirestoreError(error, OperationType.LIST, 'complaints');
    }
  );
}

// Subscribe to all complaints for Administrator
export function subscribeToAllComplaints(
  onSuccess: (complaints: Complaint[]) => void,
  onError: (error: Error) => void
) {
  const complaintsCol = collection(db, 'complaints');

  return onSnapshot(
    complaintsCol,
    (snapshot) => {
      const results: Complaint[] = [];
      snapshot.forEach((doc) => {
        results.push({ id: doc.id, ...(doc.data() as Omit<Complaint, 'id'>) });
      });
      results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onSuccess(results);
    },
    (error) => {
      onError(error);
      handleFirestoreError(error, OperationType.LIST, 'complaints');
    }
  );
}

// Fetch single complaint by ID or complaintNumber
export async function fetchComplaintByIdOrNumber(idOrNumber: string): Promise<Complaint | null> {
  const cleaned = idOrNumber.trim();
  if (!cleaned) return null;

  try {
    // Check direct doc ID
    const docRef = doc(db, 'complaints', cleaned);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { id: snap.id, ...(snap.data() as Omit<Complaint, 'id'>) };
    }

    // Check by complaintNumber
    const q = query(collection(db, 'complaints'), where('complaintNumber', '==', cleaned));
    const querySnap = await getDocs(q);
    if (!querySnap.empty) {
      const firstDoc = querySnap.docs[0];
      return { id: firstDoc.id, ...(firstDoc.data() as Omit<Complaint, 'id'>) };
    }

    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `complaints/${cleaned}`);
  }
}

// Subscribe to history of a complaint
export function subscribeToComplaintHistory(
  complaintId: string,
  onSuccess: (history: ComplaintHistory[]) => void,
  onError: (error: Error) => void
) {
  const historyCol = collection(db, 'complaints', complaintId, 'history');

  return onSnapshot(
    historyCol,
    (snapshot) => {
      const logs: ComplaintHistory[] = [];
      snapshot.forEach((d) => {
        logs.push({ id: d.id, ...(d.data() as Omit<ComplaintHistory, 'id'>) });
      });
      logs.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      onSuccess(logs);
    },
    (error) => {
      onError(error);
      handleFirestoreError(error, OperationType.LIST, `complaints/${complaintId}/history`);
    }
  );
}

// Admin update complaint status, department, remarks, resolution
export async function updateComplaintStatus(
  complaint: Complaint,
  updates: {
    status?: ComplaintStatus;
    department?: Department;
    priority?: Priority;
    adminRemarks?: string;
    resolutionDetails?: string;
  },
  adminName: string,
  adminId: string
): Promise<void> {
  const docRef = doc(db, 'complaints', complaint.id);
  const now = new Date().toISOString();

  const prevStatus = complaint.status;
  const newStatus = updates.status || complaint.status;

  const payload: Partial<Complaint> = {
    updatedAt: now,
  };

  if (updates.status !== undefined) payload.status = updates.status;
  if (updates.department !== undefined) payload.department = updates.department;
  if (updates.priority !== undefined) payload.priority = updates.priority;
  if (updates.adminRemarks !== undefined) payload.adminRemarks = updates.adminRemarks.trim();
  if (updates.resolutionDetails !== undefined) payload.resolutionDetails = updates.resolutionDetails.trim();

  try {
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `complaints/${complaint.id}`);
  }

  // Record audit history entry
  try {
    const historyCol = collection(db, 'complaints', complaint.id, 'history');
    const historyDocRef = doc(historyCol);
    const remarkNote = updates.adminRemarks
      ? updates.adminRemarks
      : updates.status && updates.status !== prevStatus
      ? `Status changed from ${prevStatus} to ${newStatus}.`
      : 'Complaint details updated by administrator.';

    const historyEntry: ComplaintHistory = {
      id: historyDocRef.id,
      complaintId: complaint.id,
      previousStatus: prevStatus,
      newStatus: newStatus,
      remarks: remarkNote,
      changedBy: adminName,
      changedById: adminId,
      timestamp: now,
    };
    await setDoc(historyDocRef, historyEntry);
  } catch (err) {
    console.warn('Could not write history log:', err);
  }
}

// Delete complaint (Admin only)
export async function deleteComplaint(complaintId: string): Promise<void> {
  const docRef = doc(db, 'complaints', complaintId);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `complaints/${complaintId}`);
  }
}

// Export complaints to formatted CSV file
export function exportComplaintsToCSV(complaints: Complaint[]) {
  const headers = [
    'Complaint Number',
    'Title',
    'Category',
    'Department',
    'Priority',
    'Status',
    'User Name',
    'User Email',
    'Location',
    'Description',
    'Admin Remarks',
    'Resolution Details',
    'Created Date',
    'Updated Date',
  ];

  const escapeCSV = (value: string | undefined | null) => {
    if (!value) return '""';
    const str = String(value).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = complaints.map((c) => [
    escapeCSV(c.complaintNumber),
    escapeCSV(c.title),
    escapeCSV(c.category),
    escapeCSV(c.department),
    escapeCSV(c.priority),
    escapeCSV(c.status),
    escapeCSV(c.userName),
    escapeCSV(c.userEmail),
    escapeCSV(c.location),
    escapeCSV(c.description),
    escapeCSV(c.adminRemarks),
    escapeCSV(c.resolutionDetails),
    escapeCSV(new Date(c.createdAt).toLocaleString()),
    escapeCSV(new Date(c.updatedAt).toLocaleString()),
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const dateStr = new Date().toISOString().split('T')[0];
  link.setAttribute('download', `complaints_report_${dateStr}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
