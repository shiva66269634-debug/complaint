import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider, BOOTSTRAP_ADMIN_EMAIL, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, Role } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, fullName: string) => Promise<void>;
  logout: () => Promise<void>;
  error: string | null;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  const syncUserProfile = async (user: FirebaseUser, overrideName?: string) => {
    try {
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);

      const isBootstrapAdmin = user.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase();

      // Check if document exists in admins collection
      let hasAdminDoc = false;
      try {
        const adminRef = doc(db, 'admins', user.uid);
        const adminSnap = await getDoc(adminRef);
        hasAdminDoc = adminSnap.exists();
      } catch (e) {
        // Ignored if permissions not ready yet
      }

      const assignedRole: Role = (isBootstrapAdmin || hasAdminDoc) ? 'admin' : 'user';

      if (!userSnap.exists()) {
        const newProfile: UserProfile = {
          userId: user.uid,
          fullName: overrideName || user.displayName || user.email?.split('@')[0] || 'User',
          email: user.email || '',
          role: assignedRole,
          createdAt: new Date().toISOString(),
        };
        await setDoc(userRef, newProfile);
        setUserProfile(newProfile);

        // If bootstrap admin, also create /admins doc
        if (isBootstrapAdmin && !hasAdminDoc) {
          try {
            await setDoc(doc(db, 'admins', user.uid), {
              userId: user.uid,
              email: user.email,
              role: 'admin',
              createdAt: new Date().toISOString(),
            });
          } catch (e) {
            console.warn('Admin doc creation notice:', e);
          }
        }
      } else {
        const existing = userSnap.data() as UserProfile;
        // If bootstrap admin, ensure role reflects admin
        if (isBootstrapAdmin && existing.role !== 'admin') {
          existing.role = 'admin';
        }
        setUserProfile(existing);
      }

      setIsAdmin(assignedRole === 'admin' || isBootstrapAdmin);
    } catch (err) {
      console.error('Error syncing profile:', err);
      // Fallback in-memory profile so user is not blocked
      const fallbackRole: Role = (user.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) ? 'admin' : 'user';
      setUserProfile({
        userId: user.uid,
        fullName: overrideName || user.displayName || user.email?.split('@')[0] || 'User',
        email: user.email || '',
        role: fallbackRole,
        createdAt: new Date().toISOString(),
      });
      setIsAdmin(fallbackRole === 'admin');
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      setCurrentUser(user);
      if (user) {
        await syncUserProfile(user);
      } else {
        setUserProfile(null);
        setIsAdmin(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      setError(null);
      const cred = await signInWithPopup(auth, googleProvider);
      await syncUserProfile(cred.user);
    } catch (err: any) {
      console.error('Google Sign-in failed:', err);
      setError(err?.message || 'Failed to sign in with Google');
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      setError(null);
      const cred = await signInWithEmailAndPassword(auth, email, pass);
      await syncUserProfile(cred.user);
    } catch (err: any) {
      console.error('Email login failed:', err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password sign-in is not enabled in Firebase Console. Please use "Sign in with Google" or enable Email/Password provider in Firebase.');
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError('Invalid email or password. Please verify your credentials.');
      } else {
        setError(err.message || 'Login failed. Please check your credentials.');
      }
      throw err;
    }
  };

  const registerWithEmail = async (email: string, pass: string, fullName: string) => {
    try {
      setError(null);
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      if (fullName) {
        await updateProfile(cred.user, { displayName: fullName });
      }
      await syncUserProfile(cred.user, fullName);
    } catch (err: any) {
      console.error('Email registration failed:', err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password registration is not enabled in Firebase Console. Please use "Sign in with Google" for instant one-click sign in.');
      } else if (err.code === 'auth/email-already-in-use') {
        setError('This email address is already registered. Please login instead.');
      } else if (err.code === 'auth/weak-password') {
        setError('Password should be at least 6 characters.');
      } else {
        setError(err.message || 'Registration failed.');
      }
      throw err;
    }
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
      setCurrentUser(null);
      setUserProfile(null);
      setIsAdmin(false);
    } catch (err: any) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        loading,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        logout,
        error,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
