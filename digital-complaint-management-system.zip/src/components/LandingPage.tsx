import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  FileText,
  Search,
  PlusCircle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Building,
  ArrowRight,
  Sparkles,
  Lock,
  Download,
  Users,
  Layers,
  GraduationCap,
} from 'lucide-react';

interface LandingPageProps {
  onNavigateTab: (tab: string) => void;
  openSubmitModal: () => void;
  openAuthModal: (mode?: 'login' | 'register') => void;
  onTrackWithNumber: (num: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigateTab,
  openSubmitModal,
  openAuthModal,
  onTrackWithNumber,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const [quickTrackNumber, setQuickTrackNumber] = useState('');

  const handleQuickTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickTrackNumber.trim()) {
      onTrackWithNumber(quickTrackNumber.trim());
    }
  };

  return (
    <div className="space-y-16 py-6 pb-16 animate-fade-in">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
              Digital Complaint <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                Management System
              </span>
            </h1>

            {/* Main Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => {
                  if (!currentUser) openAuthModal('login');
                  else openSubmitModal();
                }}
                className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition flex items-center gap-2 cursor-pointer"
              >
                <PlusCircle className="w-5 h-5" />
                Submit Complaint
              </button>

              <button
                onClick={() => onNavigateTab('track')}
                className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm border border-slate-300 shadow-sm transition flex items-center gap-2 cursor-pointer"
              >
                <Search className="w-4 h-4 text-slate-500" />
                Track Complaint
              </button>

              {!currentUser ? (
                <button
                  onClick={() => openAuthModal('register')}
                  className="px-5 py-3.5 rounded-xl text-blue-700 hover:bg-blue-50 font-semibold text-sm transition"
                >
                  Create Account →
                </button>
              ) : isAdmin ? (
                <button
                  onClick={() => onNavigateTab('admin')}
                  className="px-5 py-3.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 font-bold text-sm border border-purple-200 transition flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin Console
                </button>
              ) : (
                <button
                  onClick={() => onNavigateTab('dashboard')}
                  className="px-5 py-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-sm transition"
                >
                  View My Dashboard
                </button>
              )}
            </div>

            {/* Quick Track Widget */}
            <div className="pt-4 max-w-lg">
              <form
                onSubmit={handleQuickTrackSubmit}
                className="flex items-center gap-2 p-2 bg-white rounded-2xl border border-slate-300 shadow-sm focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100"
              >
                <Search className="w-4 h-4 text-slate-400 ml-2" />
                <input
                  type="text"
                  placeholder="Quick lookup by ID (e.g. CMP-2026-48201)..."
                  value={quickTrackNumber}
                  onChange={(e) => setQuickTrackNumber(e.target.value)}
                  className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none py-1"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition shrink-0"
                >
                  Track Now
                </button>
              </form>
            </div>
          </div>

          {/* Right Card / Interactive Preview */}
          <div className="lg:col-span-5">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 sm:p-8 text-white shadow-2xl relative overflow-hidden">
              <div className="absolute -right-8 -bottom-8 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center justify-between pb-6 border-b border-white/15">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center font-bold">
                    <ShieldCheck className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Official Complaint Desk</h3>
                    <p className="text-blue-100 text-xs">Campus Redressal SLA</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold">
                  Active System
                </span>
              </div>

              {/* Sample Workflow Card */}
              <div className="mt-6 space-y-4">
                <div className="bg-white/10 backdrop-blur rounded-xl p-4 border border-white/10 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] text-blue-200 font-bold">
                      CMP-2026-78421
                    </span>
                    <span className="px-2 py-0.5 rounded bg-emerald-400/20 text-emerald-200 font-bold text-[10px]">
                      RESOLVED
                    </span>
                  </div>
                  <p className="font-bold text-white text-sm">
                    Lab 3 Air Conditioning System Repaired
                  </p>
                  <p className="text-blue-100 text-[11px]">
                    Assigned: Electrical & HVAC Maintenance Department
                  </p>
                  <div className="pt-1 flex items-center justify-between text-[10px] text-blue-200 border-t border-white/10">
                    <span>Turnaround: 4.2 Hours</span>
                    <span>Verified by Admin</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2 text-center text-xs">
                  <div className="bg-white/10 rounded-xl p-3 border border-white/10">
                    <p className="text-xl font-extrabold">6</p>
                    <p className="text-blue-100 text-[11px]">Departments</p>
                  </div>
                  <div className="bg-white/10 rounded-xl p-3 border border-white/10">
                    <p className="text-xl font-extrabold">100%</p>
                    <p className="text-blue-100 text-[11px]">Audit Tracked</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3-Step Process Explanation Section */}
      <section className="bg-white py-14 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
              Simple & Transparent Workflow
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Three Steps: Submit, Track and Resolve
            </h2>
            <p className="text-slate-600 text-sm">
              Our automated system streamlines issue reporting without bureaucratic bottlenecks or physical forms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 relative group hover:border-blue-400 transition">
              <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg mb-4 shadow-md shadow-blue-500/20">
                1
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">1. Submit Incident</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Provide issue category, location, priority, detailed narrative, and optional photo evidence. The system immediately creates a unique tracking ID.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 relative group hover:border-blue-400 transition">
              <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg mb-4 shadow-md shadow-indigo-500/20">
                2
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">2. Department Tracking</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Administrators review and assign the petition to the responsible department (e.g., Electrical, Sanitation, IT Support). Every status transition is logged in real-time.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 relative group hover:border-blue-400 transition">
              <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg mb-4 shadow-md shadow-emerald-500/20">
                3
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">3. Verified Resolution</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Once maintenance work is concluded, officials record remarks and detailed resolution reports. Both citizen and admin dashboard reflect the verified closure.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits of the System */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
            System Advantages
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Key Institutional Benefits
          </h2>
          <p className="text-slate-600 text-sm">
            Designed to replace paper complaint registers with an accountable, transparent, and auditable digital platform.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">100% Transparency</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Users know exactly who is handling their grievance and review historical action timestamps.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Zero Paperwork Delay</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Eliminate physical paperwork losses; instant digital dispatch directly to department heads.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Role-Based Security</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Strict Firestore security rules protect PII and prevent unauthorized status manipulations.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Accredited Reporting</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Export filtered reports to CSV for NAAC, NIRF, or institutional administrative audits.
            </p>
          </div>
        </div>
      </section>

      {/* System Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 shadow-2xl">
          <div className="max-w-2xl space-y-3 mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Core Technical Features
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Engineered for Complete Lifecycle Control
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              Fully connected frontend, backend Firestore synchronization, and fine-grained permissions.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <Building className="w-5 h-5 text-blue-400" />
              <h4 className="font-bold text-sm">6 Managed Departments</h4>
              <p className="text-xs text-slate-400">
                Infrastructure, Electrical, Water & Sanitation, IT Support, Security, and General Admin.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <h4 className="font-bold text-sm">Immutable Audit Logs</h4>
              <p className="text-xs text-slate-400">
                Every status update logs previous status, new status, reviewer ID, timestamp, and remark notes.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <Users className="w-5 h-5 text-emerald-400" />
              <h4 className="font-bold text-sm">Multi-Role Authentication</h4>
              <p className="text-xs text-slate-400">
                Separate portals for regular citizens/students and authorized administrators.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">
              Digital Complaint Management System (DCMS)
            </span>
          </div>
          <div>
            © {new Date().getFullYear()} All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};
