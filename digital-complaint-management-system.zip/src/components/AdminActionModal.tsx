import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  DEPARTMENTS,
  STATUS_LIST,
  PRIORITY_LIST,
  updateComplaintStatus,
  deleteComplaint,
} from '../services/complaintService';
import { Complaint, ComplaintStatus, Department, Priority } from '../types';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import {
  X,
  ShieldCheck,
  Building,
  AlertTriangle,
  FileText,
  User,
  Trash2,
  Save,
  CheckCircle2,
  Clock,
  Calendar,
  MapPin,
} from 'lucide-react';

interface AdminActionModalProps {
  complaint: Complaint | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminActionModal: React.FC<AdminActionModalProps> = ({
  complaint,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();

  const [status, setStatus] = useState<ComplaintStatus>(complaint?.status || 'Submitted');
  const [department, setDepartment] = useState<Department>(
    complaint?.department || 'General Administration'
  );
  const [priority, setPriority] = useState<Priority>(complaint?.priority || 'Medium');
  const [adminRemarks, setAdminRemarks] = useState(complaint?.adminRemarks || '');
  const [resolutionDetails, setResolutionDetails] = useState(
    complaint?.resolutionDetails || ''
  );

  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync state when complaint prop changes
  React.useEffect(() => {
    if (complaint) {
      setStatus(complaint.status);
      setDepartment(complaint.department);
      setPriority(complaint.priority);
      setAdminRemarks(complaint.adminRemarks || '');
      setResolutionDetails(complaint.resolutionDetails || '');
      setConfirmDelete(false);
      setErrorMessage(null);
    }
  }, [complaint]);

  if (!isOpen || !complaint) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMessage(null);

    const adminName = userProfile?.fullName || currentUser?.displayName || 'Administrator';
    const adminId = currentUser?.uid || 'admin';

    try {
      await updateComplaintStatus(
        complaint,
        {
          status,
          department,
          priority,
          adminRemarks,
          resolutionDetails,
        },
        adminName,
        adminId
      );
      onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Failed to update complaint:', err);
      setErrorMessage(err?.message || 'Failed to update complaint. Please verify permissions.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }

    setDeleting(true);
    setErrorMessage(null);
    try {
      await deleteComplaint(complaint.id);
      onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Delete failed:', err);
      setErrorMessage(err?.message || 'Failed to delete complaint.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                  {complaint.complaintNumber}
                </span>
                <span className="text-xs uppercase tracking-wider font-semibold text-slate-300">
                  Admin Resolution Desk
                </span>
              </div>
              <h2 className="text-base font-bold mt-0.5 line-clamp-1">{complaint.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSave} className="p-6 space-y-6">
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {errorMessage}
            </div>
          )}

          {/* Details Overview Banner */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-500 block font-medium">Complainant</span>
              <p className="font-bold text-slate-900 mt-0.5">{complaint.userName}</p>
              <p className="text-slate-500 text-[11px]">{complaint.userEmail}</p>
            </div>
            <div>
              <span className="text-slate-500 block font-medium">Category & Location</span>
              <p className="font-bold text-slate-900 mt-0.5">{complaint.category}</p>
              <div className="flex items-center gap-1 text-slate-600 text-[11px]">
                <MapPin className="w-3 h-3 text-rose-500" />
                <span>{complaint.location}</span>
              </div>
            </div>
            <div>
              <span className="text-slate-500 block font-medium">Logged Date</span>
              <p className="font-bold text-slate-900 mt-0.5">
                {new Date(complaint.createdAt).toLocaleString()}
              </p>
              <div className="mt-1 flex items-center gap-1.5">
                <span className="text-slate-500">Current:</span>
                <StatusBadge status={complaint.status} size="sm" />
              </div>
            </div>
          </div>

          {/* Description & Evidence */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Complaint Narrative & Evidence
            </h4>
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-wrap max-h-40 overflow-y-auto">
              {complaint.description}
            </div>

            {complaint.attachmentUrl && (
              <div className="mt-3 flex items-center gap-3 p-2 rounded-xl border border-slate-200 bg-white max-w-sm">
                <img
                  src={complaint.attachmentUrl}
                  alt="Evidence"
                  className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                />
                <div>
                  <p className="text-xs font-bold text-slate-800">Photo Evidence Attached</p>
                  <a
                    href={complaint.attachmentUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-blue-600 hover:underline"
                  >
                    View Full Image
                  </a>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-slate-200 pt-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Departmental Action & Status Controls
            </h3>

            {/* Department, Status, Priority in 3 cols */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Department */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Assign Department
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value as Department)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Update Lifecycle Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ComplaintStatus)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {STATUS_LIST.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              {/* Priority */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Urgency / Priority
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {PRIORITY_LIST.map((pr) => (
                    <option key={pr} value={pr}>
                      {pr} Priority
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Administrator Remarks */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Administrator Remarks (Visible to Citizen)
              </label>
              <textarea
                rows={2}
                maxLength={2000}
                placeholder="e.g. Assigned to Electrical Maintenance team. Repair technician dispatched to inspect the wiring."
                value={adminRemarks}
                onChange={(e) => setAdminRemarks(e.target.value)}
                className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Resolution Details */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Official Resolution Details (Required if marking Resolved)
              </label>
              <textarea
                rows={3}
                maxLength={2000}
                placeholder="Describe actions taken, work completed, parts replaced, and preventive measures implemented..."
                value={resolutionDetails}
                onChange={(e) => setResolutionDetails(e.target.value)}
                className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Delete button with double-confirmation */}
            <div>
              {confirmDelete ? (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-rose-600 font-bold">Are you sure?</span>
                  <button
                    type="button"
                    onClick={handleDelete}
                    disabled={deleting}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition"
                  >
                    {deleting ? 'Deleting...' : 'Yes, Permanently Delete'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(false)}
                    className="px-2 py-1.5 text-xs text-slate-500 hover:underline"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="px-3 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 border border-rose-200 text-xs font-semibold flex items-center gap-1.5 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete Complaint
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="w-1/2 sm:w-auto px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="w-1/2 sm:w-auto px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-60"
              >
                {saving ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save & Update Database</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
