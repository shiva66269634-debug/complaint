import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  FileText,
  Search,
  PlusCircle,
  LayoutDashboard,
  ShieldCheck,
  LogOut,
  LogIn,
  Menu,
  X,
  User,
  GraduationCap,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openAuthModal: (mode?: 'login' | 'register') => void;
  openSubmitModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openAuthModal,
  openSubmitModal,
}) => {
  const { currentUser, userProfile, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (tab: string) => {
    setCurrentTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            onClick={() => handleNav('landing')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-lg leading-tight tracking-tight">
                  DCMS
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 hidden sm:inline-block">
                  Official Portal
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden md:block">
                Digital Complaint Management System
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => handleNav('landing')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition ${
                currentTab === 'landing'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => {
                if (!currentUser) {
                  openAuthModal('login');
                } else {
                  openSubmitModal();
                }
              }}
              className="px-3 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 flex items-center gap-1.5 transition"
            >
              <PlusCircle className="w-4 h-4 text-blue-600" />
              Submit Complaint
            </button>
            <button
              onClick={() => handleNav('track')}
              className={`px-3 py-2 text-sm font-medium rounded-lg flex items-center gap-1.5 transition ${
                currentTab === 'track'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Search className="w-4 h-4 text-slate-500" />
              Track Status
            </button>
            {currentUser && (
              <button
                onClick={() => handleNav('dashboard')}
                className={`px-3 py-2 text-sm font-medium rounded-lg flex items-center gap-1.5 transition ${
                  currentTab === 'dashboard'
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 text-slate-500" />
                My Dashboard
              </button>
            )}
            {currentUser && isAdmin && (
              <button
                onClick={() => handleNav('admin')}
                className={`px-3 py-2 text-sm font-semibold rounded-lg flex items-center gap-1.5 transition ${
                  currentTab === 'admin'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                Admin Portal
              </button>
            )}
          </nav>

          {/* User Auth controls */}
          <div className="hidden md:flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2.5 pl-3 border-l border-slate-200">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs uppercase border border-blue-200">
                    {userProfile?.fullName?.[0] || currentUser.email?.[0] || 'U'}
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-slate-900 leading-none">
                      {userProfile?.fullName || currentUser.displayName || 'Authenticated User'}
                    </p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span
                        className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                          isAdmin
                            ? 'bg-purple-100 text-purple-800 font-bold'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {isAdmin ? 'ADMINISTRATOR' : 'CITIZEN / USER'}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => logout()}
                  title="Sign Out"
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openAuthModal('login')}
                  className="px-3.5 py-1.5 text-sm font-medium text-slate-700 hover:text-blue-600 hover:bg-slate-50 rounded-lg transition"
                >
                  Log In
                </button>
                <button
                  onClick={() => openAuthModal('register')}
                  className="px-3.5 py-1.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-2">
          <button
            onClick={() => handleNav('landing')}
            className="w-full text-left px-3 py-2 text-sm font-medium rounded-lg text-slate-700 hover:bg-slate-100"
          >
            Home
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              if (!currentUser) openAuthModal('login');
              else openSubmitModal();
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium rounded-lg text-blue-600 bg-blue-50 hover:bg-blue-100 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            Submit Complaint
          </button>
          <button
            onClick={() => handleNav('track')}
            className="w-full text-left px-3 py-2 text-sm font-medium rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-2"
          >
            <Search className="w-4 h-4" />
            Track Status
          </button>
          {currentUser && (
            <button
              onClick={() => handleNav('dashboard')}
              className="w-full text-left px-3 py-2 text-sm font-medium rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-2"
            >
              <LayoutDashboard className="w-4 h-4" />
              My Dashboard
            </button>
          )}
          {currentUser && isAdmin && (
            <button
              onClick={() => handleNav('admin')}
              className="w-full text-left px-3 py-2 text-sm font-semibold rounded-lg text-white bg-blue-600 flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              Admin Portal
            </button>
          )}
          <div className="pt-3 border-t border-slate-200">
            {currentUser ? (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-slate-900">
                    {userProfile?.fullName || currentUser.email}
                  </p>
                  <p className="text-xs text-slate-500">
                    {isAdmin ? 'Administrator' : 'Standard User'}
                  </p>
                </div>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 rounded-lg hover:bg-rose-100 flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Logout
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    openAuthModal('login');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 text-center text-sm font-medium text-slate-700 border border-slate-300 rounded-lg"
                >
                  Log In
                </button>
                <button
                  onClick={() => {
                    openAuthModal('register');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 text-center text-sm font-semibold text-white bg-blue-600 rounded-lg"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
