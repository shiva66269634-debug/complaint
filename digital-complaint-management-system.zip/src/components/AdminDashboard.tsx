import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  subscribeToAllComplaints,
  exportComplaintsToCSV,
  COMPLAINT_CATEGORIES,
  DEPARTMENTS,
  STATUS_LIST,
  PRIORITY_LIST,
} from '../services/complaintService';
import { Complaint, ComplaintStatus, Department, Priority, ComplaintCategory } from '../types';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { AdminActionModal } from './AdminActionModal';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  ShieldCheck,
  FileText,
  Clock,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Download,
  Search,
  Filter,
  ArrowUpDown,
  Building,
  Eye,
  Settings,
  Sparkles,
  BarChart3,
  PieChart as PieChartIcon,
} from 'lucide-react';

interface AdminDashboardProps {
  onTrackComplaint: (complaintNumber: string) => void;
}

const STATUS_COLORS: Record<ComplaintStatus, string> = {
  Submitted: '#3b82f6', // blue-500
  Pending: '#f59e0b', // amber-500
  'In Progress': '#6366f1', // indigo-500
  Resolved: '#10b981', // emerald-500
  Rejected: '#f43f5e', // rose-500
};

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onTrackComplaint }) => {
  const { userProfile, currentUser } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All');
  const [selectedPriority, setSelectedPriority] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Selected complaint for modal action
  const [activeComplaint, setActiveComplaint] = useState<Complaint | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToAllComplaints(
      (data) => {
        setComplaints(data);
        setLoading(false);
      },
      (error) => {
        console.error('Failed to load all complaints:', error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Filtered & Sorted complaints
  const filteredComplaints = useMemo(() => {
    return complaints
      .filter((c) => {
        const matchesSearch =
          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.complaintNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.location.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesStatus = selectedStatus === 'All' || c.status === selectedStatus;
        const matchesDept = selectedDepartment === 'All' || c.department === selectedDepartment;
        const matchesPriority = selectedPriority === 'All' || c.priority === selectedPriority;
        const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;

        return matchesSearch && matchesStatus && matchesDept && matchesPriority && matchesCategory;
      })
      .sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
      });
  }, [
    complaints,
    searchQuery,
    selectedStatus,
    selectedDepartment,
    selectedPriority,
    selectedCategory,
    sortOrder,
  ]);

  // Statistics
  const totalCount = complaints.length;
  const submittedCount = complaints.filter((c) => c.status === 'Submitted').length;
  const pendingCount = complaints.filter((c) => c.status === 'Pending').length;
  const inProgressCount = complaints.filter((c) => c.status === 'In Progress').length;
  const resolvedCount = complaints.filter((c) => c.status === 'Resolved').length;
  const rejectedCount = complaints.filter((c) => c.status === 'Rejected').length;

  // Chart data: By Status
  const statusChartData = useMemo(() => {
    return STATUS_LIST.map((status) => ({
      name: status,
      value: complaints.filter((c) => c.status === status).length,
      color: STATUS_COLORS[status],
    })).filter((item) => item.value > 0);
  }, [complaints]);

  // Chart data: By Category
  const categoryChartData = useMemo(() => {
    return COMPLAINT_CATEGORIES.map((cat) => ({
      name: cat.length > 12 ? cat.substring(0, 10) + '...' : cat,
      fullName: cat,
      count: complaints.filter((c) => c.category === cat).length,
    })).filter((item) => item.count > 0);
  }, [complaints]);

  // Chart data: By Department
  const departmentChartData = useMemo(() => {
    return DEPARTMENTS.map((dept) => ({
      name: dept.replace(' Department', '').replace('General Administration', 'Gen Admin'),
      fullName: dept,
      count: complaints.filter((c) => c.department === dept).length,
    }));
  }, [complaints]);

  const handleOpenActionModal = (c: Complaint) => {
    setActiveComplaint(c);
    setIsModalOpen(true);
  };

  const handleExportCSV = () => {
    exportComplaintsToCSV(filteredComplaints);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-400/30 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              Administrative Command Center
            </span>
            <span className="text-xs text-slate-400">Live Database Sync</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1 tracking-tight">
            Institutional Complaint Management Console
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1 max-w-2xl">
            Review citizen petitions, assign specialized campus departments, audit status progression, and generate accredited reports.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            disabled={filteredComplaints.length === 0}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            Export CSV Report ({filteredComplaints.length})
          </button>
        </div>
      </div>

      {/* 6 Statistical Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>Total Logged</span>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">{totalCount}</p>
        </div>

        {/* Submitted */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-blue-600 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>Submitted</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-extrabold text-blue-700 mt-1">{submittedCount}</p>
        </div>

        {/* Pending */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-amber-600 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>Pending</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-extrabold text-amber-700 mt-1">{pendingCount}</p>
        </div>

        {/* In Progress */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-indigo-600 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>In Progress</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-2xl font-extrabold text-indigo-700 mt-1">{inProgressCount}</p>
        </div>

        {/* Resolved */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-emerald-600 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-extrabold text-emerald-700 mt-1">{resolvedCount}</p>
        </div>

        {/* Rejected */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-rose-600 text-xs font-medium uppercase tracking-wider flex items-center justify-between">
            <span>Rejected</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-extrabold text-rose-700 mt-1">{rejectedCount}</p>
        </div>
      </div>

      {/* Visual Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Distribution Pie Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <PieChartIcon className="w-4 h-4 text-blue-600" />
              Status Breakdown
            </h3>
            <span className="text-xs text-slate-400">Total: {totalCount}</span>
          </div>

          {statusChartData.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-xs text-slate-400 py-12">
              No complaint data yet
            </div>
          ) : (
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {statusChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: any, name: any) => [`${val} complaints`, name]}
                    contentStyle={{ fontSize: '12px', borderRadius: '8px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Categories Bar Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-blue-600" />
              Complaints by Category
            </h3>
            <span className="text-xs text-slate-400">Institutional Demographics</span>
          </div>

          {categoryChartData.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-xs text-slate-400 py-12">
              No category data yet
            </div>
          ) : (
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 10 }}
                    angle={-20}
                    textAnchor="end"
                    interval={0}
                  />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip
                    formatter={(val: any, name: any, item: any) => [
                      `${val} cases`,
                      item.payload.fullName,
                    ]}
                    contentStyle={{ fontSize: '12px', borderRadius: '8px' }}
                  />
                  <Bar dataKey="count" fill="#2563eb" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Main Complaints Management Table & Filter Toolbar */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Advanced Filter Toolbar */}
        <div className="p-5 border-b border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Complaints Registry</h2>
              <p className="text-xs text-slate-500">
                Displaying {filteredComplaints.length} of {totalCount} total submissions
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Sort Order */}
              <button
                onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                {sortOrder === 'newest' ? 'Newest First' : 'Oldest First'}
              </button>
            </div>
          </div>

          {/* Search and Filters grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search */}
            <div className="relative lg:col-span-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search ID, title, user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Status Filter */}
            <div>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="All">All Statuses</option>
                {STATUS_LIST.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Department Filter */}
            <div>
              <select
                value={selectedDepartment}
                onChange={(e) => setSelectedDepartment(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="All">All Departments</option>
                {DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            {/* Category Filter */}
            <div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="All">All Categories</option>
                {COMPLAINT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Priority Filter */}
            <div>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="All">All Priorities</option>
                {PRIORITY_LIST.map((pr) => (
                  <option key={pr} value={pr}>
                    {pr} Priority
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Complaints Data Table */}
        {loading ? (
          <div className="p-12 text-center text-slate-500">
            <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-sm">Synchronizing administrative records...</p>
          </div>
        ) : filteredComplaints.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-700">No complaints found</p>
            <p className="text-xs text-slate-500">
              No records match your active search or filter parameters.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                  <th className="py-3.5 px-4">Complaint ID</th>
                  <th className="py-3.5 px-4">Complainant</th>
                  <th className="py-3.5 px-4">Title & Details</th>
                  <th className="py-3.5 px-4">Department</th>
                  <th className="py-3.5 px-4">Priority</th>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredComplaints.map((c) => (
                  <tr key={c.id} className="hover:bg-blue-50/40 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-blue-700 whitespace-nowrap">
                      {c.complaintNumber}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <p className="font-semibold text-slate-900">{c.userName}</p>
                      <p className="text-[11px] text-slate-400">{c.userEmail}</p>
                    </td>
                    <td className="py-3.5 px-4 max-w-xs">
                      <p className="font-bold text-slate-800 line-clamp-1">{c.title}</p>
                      <span className="text-[11px] text-slate-500">{c.category} • {c.location}</span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-slate-700">
                        <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate max-w-[130px]">{c.department}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <PriorityBadge priority={c.priority} />
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 whitespace-nowrap">
                      {new Date(c.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <StatusBadge status={c.status} size="sm" />
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-1.5">
                      <button
                        onClick={() => handleOpenActionModal(c)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-xs"
                      >
                        <Settings className="w-3 h-3" />
                        Review / Update
                      </button>
                      <button
                        onClick={() => onTrackComplaint(c.complaintNumber)}
                        title="View Public Tracker"
                        className="inline-flex items-center p-1.5 rounded-lg text-slate-500 hover:text-blue-700 hover:bg-slate-100 transition"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Admin Action Modal for updating status, remarks, department */}
      <AdminActionModal
        complaint={activeComplaint}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setActiveComplaint(null);
        }}
        onSuccess={() => {
          // Updates flow through real-time listener automatically
        }}
      />
    </div>
  );
};
