import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  COMPLAINT_CATEGORIES,
  DEPARTMENTS,
  PRIORITY_LIST,
  CATEGORY_DEPARTMENT_MAP,
  submitComplaint,
} from '../services/complaintService';
import { ComplaintCategory, Department, Priority, Complaint } from '../types';
import {
  X,
  Send,
  Upload,
  AlertCircle,
  CheckCircle2,
  Copy,
  MapPin,
  Building,
  Tag,
  Flame,
  FileImage,
  ArrowRight,
} from 'lucide-react';

interface ComplaintSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessComplaint?: (complaint: Complaint) => void;
}

export const ComplaintSubmissionModal: React.FC<ComplaintSubmissionModalProps> = ({
  isOpen,
  onClose,
  onSuccessComplaint,
}) => {
  const { currentUser, userProfile } = useAuth();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>('Infrastructure');
  const [department, setDepartment] = useState<Department>('Infrastructure Department');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [fileError, setFileError] = useState<string | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdComplaint, setCreatedComplaint] = useState<Complaint | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCategoryChange = (newCat: ComplaintCategory) => {
    setCategory(newCat);
    if (CATEGORY_DEPARTMENT_MAP[newCat]) {
      setDepartment(CATEGORY_DEPARTMENT_MAP[newCat]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFileError('Only image files (PNG, JPG, WEBP) are supported.');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setFileError('File size exceeds the 2MB limit. Please upload a smaller image.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAttachmentUrl(reader.result as string);
      setFileName(file.name);
    };
    reader.readAsDataURL(file);
  };

  const removeAttachment = () => {
    setAttachmentUrl('');
    setFileName('');
    setFileError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setError(null);
    if (!title.trim() || !description.trim() || !location.trim()) {
      setError('Please fill in all mandatory fields.');
      return;
    }

    setSubmitting(true);
    try {
      const complaint = await submitComplaint({
        userId: currentUser.uid,
        userName: userProfile?.fullName || currentUser.displayName || 'Citizen',
        userEmail: currentUser.email || 'user@example.com',
        title,
        category,
        description,
        location,
        department,
        priority,
        attachmentUrl: attachmentUrl || undefined,
      });

      setCreatedComplaint(complaint);
      if (onSuccessComplaint) {
        onSuccessComplaint(complaint);
      }
    } catch (err: any) {
      console.error('Submission error:', err);
      let msg = err?.message || 'Failed to submit complaint. Please try again.';
      try {
        const parsed = JSON.parse(msg);
        if (parsed.error) {
          msg = parsed.error.includes('Missing or insufficient permissions')
            ? 'Account authorization notice. Please ensure you are logged in.'
            : parsed.error;
        }
      } catch (e) {
        // Not JSON
      }
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetAndClose = () => {
    setTitle('');
    setLocation('');
    setDescription('');
    setAttachmentUrl('');
    setFileName('');
    setCreatedComplaint(null);
    setCopied(false);
    onClose();
  };

  const copyComplaintNumber = () => {
    if (createdComplaint) {
      navigator.clipboard.writeText(createdComplaint.complaintNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const wordCount = description.trim() ? description.trim().split(/\s+/).length : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-700 text-white flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">Lodge a New Complaint</h2>
            <p className="text-blue-100 text-xs">
              Provide incident details and general location for prompt resolution
            </p>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success View */}
        {createdComplaint ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                Complaint Registered Successfully!
              </h3>
              <p className="text-slate-600 text-sm mt-1">
                Your complaint has been logged in the system and routed to the{' '}
                <strong className="text-blue-700">{createdComplaint.department}</strong>.
              </p>
            </div>

            {/* Complaint ID Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 max-w-md mx-auto">
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-500">
                Your Tracking ID / Complaint Number
              </span>
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="font-mono text-2xl font-extrabold text-blue-700">
                  {createdComplaint.complaintNumber}
                </span>
                <button
                  onClick={copyComplaintNumber}
                  title="Copy ID"
                  className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
              {copied && <p className="text-xs text-emerald-600 font-semibold mt-1">Copied to clipboard!</p>}
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleResetAndClose}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-md transition"
              >
                Go to Dashboard
              </button>
              <button
                onClick={() => {
                  setCreatedComplaint(null);
                  setTitle('');
                  setDescription('');
                  setLocation('');
                  setAttachmentUrl('');
                  setFileName('');
                }}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-sm font-semibold transition"
              >
                Submit Another Complaint
              </button>
            </div>
          </div>
        ) : (
          /* Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Title */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Complaint Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                maxLength={200}
                placeholder="e.g. Broken water pipeline outside Science Block B"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Category & Department Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Category <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <select
                    value={category}
                    onChange={(e) => handleCategoryChange(e.target.value as ComplaintCategory)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {COMPLAINT_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Assigned Department
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value as Department)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Location (Approximate or Specific) - full width, priority removed */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Location / Area (Approximate or Specific) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  maxLength={200}
                  placeholder="e.g. Near Library, Science Block, Canteen, Ground Floor, or General Campus"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Exact room number is not required. Just mention the general place, block, or nearby landmark.
              </p>
            </div>

            {/* Brief Description (small info ~200 words) */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Complaint Description <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">
                  {wordCount} words (around 200 words is enough)
                </span>
              </div>
              <textarea
                required
                rows={3}
                maxLength={5000}
                placeholder="Briefly describe what the issue is (a few sentences is plenty)..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <p className="text-[11px] text-slate-500 mt-0.5">
                Only a brief description is needed — a few sentences or up to ~200 words is plenty.
              </p>
            </div>

            {/* Image Attachment (Completely Optional) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Supporting Photo / Attachment (Optional - Not Mandatory)
                </label>
                <span className="text-[11px] text-emerald-600 font-semibold">Optional</span>
              </div>
              <p className="text-[11px] text-slate-500 mb-2">
                Proof pictures are NOT mandatory. You can submit your complaint without uploading any photo.
              </p>
              {attachmentUrl ? (
                <div className="relative rounded-xl border border-slate-200 p-2 bg-slate-50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={attachmentUrl}
                      alt="Attachment Preview"
                      className="w-14 h-14 object-cover rounded-lg border border-slate-200"
                    />
                    <div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">{fileName || 'Attachment image'}</p>
                      <span className="text-[11px] text-emerald-600 font-medium">Ready to upload</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={removeAttachment}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer bg-slate-50/50 hover:bg-blue-50/30 transition">
                  <Upload className="w-5 h-5 text-slate-400 mb-1" />
                  <span className="text-xs font-medium text-slate-600">
                    Click to attach photo (or skip this step)
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5">PNG, JPG, WEBP up to 2MB (optional)</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              )}
              {fileError && <p className="text-xs text-rose-600 mt-1">{fileError}</p>}
            </div>
            <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/20 transition flex items-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit Complaint</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
