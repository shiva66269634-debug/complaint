import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  fetchComplaintByIdOrNumber,
  subscribeToComplaintHistory,
  subscribeToUserComplaints,
} from '../services/complaintService';
import { Complaint, ComplaintHistory } from '../types';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import {
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  Building,
  MapPin,
  Calendar,
  MessageSquare,
  ShieldCheck,
  History,
  FileText,
  User,
  ArrowRight,
} from 'lucide-react';

interface ComplaintTrackingViewProps {
  initialComplaintNumber?: string;
  onOpenSubmit: () => void;
}

export const ComplaintTrackingView: React.FC<ComplaintTrackingViewProps> = ({
  initialComplaintNumber = '',
  onOpenSubmit,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const [searchTerm, setSearchTerm] = useState(initialComplaintNumber);
  const [searchedComplaint, setSearchedComplaint] = useState<Complaint | null>(null);
  const [historyLogs, setHistoryLogs] = useState<ComplaintHistory[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick list of user's complaints for easy one-click selection
  const [userComplaints, setUserComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    if (currentUser) {
      const unsub = subscribeToUserComplaints(
        currentUser.uid,
        (data) => setUserComplaints(data),
        (err) => console.log('Notice loading user complaints:', err)
      );
      return () => unsub();
    }
  }, [currentUser]);

  useEffect(() => {
    if (initialComplaintNumber) {
      handleSearch(initialComplaintNumber);
    }
  }, [initialComplaintNumber]);

  // Subscribe to history logs when searchedComplaint is active
  useEffect(() => {
    if (searchedComplaint) {
      const unsub = subscribeToComplaintHistory(
        searchedComplaint.id,
        (logs) => setHistoryLogs(logs),
        (err) => console.log('Notice loading history:', err)
      );
      return () => unsub();
    } else {
      setHistoryLogs([]);
    }
  }, [searchedComplaint?.id]);

  const handleSearch = async (termToSearch?: string) => {
    const term = (termToSearch !== undefined ? termToSearch : searchTerm).trim();
    if (!term) return;

    setLoading(true);
    setSearched(true);
    setErrorMessage(null);

    try {
      const result = await fetchComplaintByIdOrNumber(term);
      if (result) {
        setSearchedComplaint(result);
      } else {
        setSearchedComplaint(null);
        setErrorMessage(`No complaint record found matching "${term}". Please double-check your Complaint Number.`);
      }
    } catch (err: any) {
      setSearchedComplaint(null);
      setErrorMessage('Unable to look up complaint. Please ensure you are logged in to view your complaints.');
    } finally {
      setLoading(false);
    }
  };

  // Determine active steps
  const steps = ['Submitted', 'Pending', 'In Progress', 'Resolved'];
  const getStepStatus = (stepName: string) => {
    if (!searchedComplaint) return 'upcoming';
    const current = searchedComplaint.status;

    if (current === 'Rejected') {
      if (stepName === 'Submitted') return 'completed';
      return 'rejected';
    }

    const order = ['Submitted', 'Pending', 'In Progress', 'Resolved'];
    const currentIndex = order.indexOf(current);
    const stepIndex = order.indexOf(stepName);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'upcoming';
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      {/* Header & Search */}
      <div className="text-center space-y-3">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
          <Search className="w-3.5 h-3.5" />
          Real-Time Public & Private Tracking
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Track Complaint Progress
        </h1>
        <p className="text-slate-600 text-sm max-w-xl mx-auto">
          Enter your unique Complaint ID (e.g., <code className="text-blue-700 font-mono font-bold">CMP-2026-XXXXX</code>) to review the assigned department, administrative remarks, and status timeline.
        </p>

        {/* Search input bar */}
        <div className="max-w-xl mx-auto mt-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className="flex items-center gap-2 bg-white p-2 rounded-2xl shadow-lg shadow-blue-500/5 border border-slate-300 focus-within:border-blue-600 focus-within:ring-2 focus-within:ring-blue-100 transition"
          >
            <Search className="w-5 h-5 text-slate-400 ml-3 shrink-0" />
            <input
              type="text"
              placeholder="Enter Complaint Number (e.g. CMP-2026-48201)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-2 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md transition shrink-0 cursor-pointer disabled:opacity-60"
            >
              {loading ? 'Searching...' : 'Track'}
            </button>
          </form>

          {/* Quick chips if logged in */}
          {userComplaints.length > 0 && (
            <div className="mt-3 flex items-center justify-center flex-wrap gap-2 text-xs">
              <span className="text-slate-500 font-medium">Your recent complaints:</span>
              {userComplaints.slice(0, 3).map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setSearchTerm(c.complaintNumber);
                    handleSearch(c.complaintNumber);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 font-mono text-xs font-semibold transition border border-slate-200"
                >
                  {c.complaintNumber}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Error message */}
      {errorMessage && (
        <div className="max-w-xl mx-auto p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-sm flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Complaint Not Found</p>
            <p className="text-xs text-amber-700 mt-0.5">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Searched Complaint Details */}
      {searchedComplaint && (
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          {/* Top Banner */}
          <div className="p-6 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold text-blue-400 bg-blue-950/80 px-2.5 py-1 rounded-md border border-blue-800">
                  {searchedComplaint.complaintNumber}
                </span>
                <StatusBadge status={searchedComplaint.status} />
                <PriorityBadge priority={searchedComplaint.priority} />
              </div>
              <h2 className="text-xl font-bold mt-2 text-white">{searchedComplaint.title}</h2>
            </div>
            <div className="text-right text-xs text-slate-400">
              <p>Submitted on: {new Date(searchedComplaint.createdAt).toLocaleDateString()}</p>
              <p>Last Activity: {new Date(searchedComplaint.updatedAt).toLocaleTimeString()}</p>
            </div>
          </div>

          {/* Stepper Timeline */}
          <div className="p-6 bg-slate-50 border-b border-slate-200">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-6">
              Resolution Progress Flow
            </h3>

            {searchedComplaint.status === 'Rejected' ? (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-3">
                <XCircle className="w-6 h-6 text-rose-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">Complaint Status: Rejected</h4>
                  <p className="text-xs text-rose-700 mt-0.5">
                    This complaint was reviewed and closed as rejected by the department. Check administrator remarks below.
                  </p>
                </div>
              </div>
            ) : (
              <div className="relative">
                <div className="hidden sm:block absolute top-1/2 left-0 right-0 h-1 bg-slate-200 -translate-y-1/2 z-0" />
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 relative z-10">
                  {steps.map((st, idx) => {
                    const statusState = getStepStatus(st);
                    return (
                      <div key={st} className="flex flex-col items-center text-center">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all shadow-sm ${
                            statusState === 'completed'
                              ? 'bg-emerald-600 text-white ring-4 ring-emerald-100'
                              : statusState === 'active'
                              ? 'bg-blue-600 text-white ring-4 ring-blue-100 animate-pulse'
                              : 'bg-white border-2 border-slate-300 text-slate-400'
                          }`}
                        >
                          {statusState === 'completed' ? (
                            <CheckCircle2 className="w-5 h-5" />
                          ) : (
                            idx + 1
                          )}
                        </div>
                        <span
                          className={`mt-2 text-xs font-semibold ${
                            statusState === 'completed'
                              ? 'text-emerald-700'
                              : statusState === 'active'
                              ? 'text-blue-700 font-bold'
                              : 'text-slate-500'
                          }`}
                        >
                          {st}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Details Body */}
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Left 2 Cols: Main Info & Remarks */}
            <div className="md:col-span-2 space-y-6">
              {/* Description */}
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Complaint Description
                </h4>
                <p className="text-sm text-slate-800 bg-slate-50 p-4 rounded-xl border border-slate-200 leading-relaxed whitespace-pre-wrap">
                  {searchedComplaint.description}
                </p>
              </div>

              {/* Administrator Remarks & Resolution Details */}
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
                  <div className="flex items-center gap-2 text-blue-900 font-bold text-xs uppercase tracking-wider mb-1">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    Administrator Remarks
                  </div>
                  <p className="text-sm text-slate-800">
                    {searchedComplaint.adminRemarks || (
                      <span className="italic text-slate-500">
                        No administrative remarks entered yet. Complaint is pending department review.
                      </span>
                    )}
                  </p>
                </div>

                {searchedComplaint.resolutionDetails && (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs uppercase tracking-wider mb-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Resolution Report & Actions Taken
                    </div>
                    <p className="text-sm text-slate-800 leading-relaxed">
                      {searchedComplaint.resolutionDetails}
                    </p>
                  </div>
                )}
              </div>

              {/* Attached Image if exists */}
              {searchedComplaint.attachmentUrl && (
                <div>
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Attached Evidence / Image
                  </h4>
                  <div className="rounded-xl border border-slate-200 overflow-hidden bg-slate-900 max-w-md">
                    <img
                      src={searchedComplaint.attachmentUrl}
                      alt="Complaint Evidence"
                      className="w-full max-h-80 object-contain mx-auto"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Right 1 Col: Metadata Sidebar & Audit Log */}
            <div className="space-y-6">
              {/* Meta Card */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block font-medium">Assigned Department</span>
                  <div className="flex items-center gap-1.5 font-bold text-slate-800 text-sm mt-0.5">
                    <Building className="w-4 h-4 text-blue-600" />
                    {searchedComplaint.department}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 block font-medium">Category</span>
                  <span className="font-semibold text-slate-800 text-sm">{searchedComplaint.category}</span>
                </div>

                <div>
                  <span className="text-slate-500 block font-medium">Location</span>
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800 text-sm mt-0.5">
                    <MapPin className="w-4 h-4 text-rose-500" />
                    {searchedComplaint.location}
                  </div>
                </div>

                {/* Show Complainant identity if current user owns or is admin */}
                {(isAdmin || currentUser?.uid === searchedComplaint.userId) && (
                  <div className="pt-2 border-t border-slate-200">
                    <span className="text-slate-500 block font-medium">Complainant Details</span>
                    <p className="font-bold text-slate-800">{searchedComplaint.userName}</p>
                    <p className="text-slate-500">{searchedComplaint.userEmail}</p>
                  </div>
                )}
              </div>

              {/* Audit History Timeline */}
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider text-slate-700 mb-3">
                  <History className="w-4 h-4 text-blue-600" />
                  Audit Trail & History
                </div>

                {historyLogs.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No status transitions logged yet.</p>
                ) : (
                  <div className="space-y-3 relative before:absolute before:inset-0 before:left-2 before:w-0.5 before:bg-slate-200">
                    {historyLogs.map((log) => (
                      <div key={log.id} className="relative pl-6 text-xs">
                        <div className="absolute left-1 top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-white" />
                        <div className="font-semibold text-slate-800">
                          {log.previousStatus !== 'None' ? (
                            <>
                              <span className="text-slate-500">{log.previousStatus}</span> →{' '}
                              <span className="text-blue-700">{log.newStatus}</span>
                            </>
                          ) : (
                            <span className="text-blue-700">Initial Submission</span>
                          )}
                        </div>
                        <p className="text-slate-600 text-[11px] mt-0.5">{log.remarks}</p>
                        <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                          <span>By: {log.changedBy}</span>
                          <span>{new Date(log.timestamp).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Initial empty state prompt */}
      {!searchedComplaint && !loading && !errorMessage && (
        <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm text-center max-w-xl mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <FileText className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Track Any Active Complaint</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Every submitted complaint receives an automated reference tracking number. Enter it above to see current resolution stage, department routing, and administrator comments.
          </p>
          <div className="pt-2">
            <button
              onClick={onOpenSubmit}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition"
            >
              Submit a New Complaint Instead
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
