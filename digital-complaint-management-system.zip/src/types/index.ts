export type Role = 'user' | 'admin';

export interface UserProfile {
  userId: string;
  fullName: string;
  email: string;
  role: Role;
  createdAt: string;
}

export type ComplaintCategory =
  | 'Infrastructure'
  | 'Electricity'
  | 'Water Supply'
  | 'Sanitation and Cleanliness'
  | 'Technical Issues'
  | 'Safety and Security'
  | 'Public Services'
  | 'Other';

export type Department =
  | 'Infrastructure Department'
  | 'Electrical Department'
  | 'Water and Sanitation Department'
  | 'IT Support Department'
  | 'Security Department'
  | 'General Administration';

export type Priority = 'Low' | 'Medium' | 'High';

export type ComplaintStatus = 'Submitted' | 'Pending' | 'In Progress' | 'Resolved' | 'Rejected';

export interface Complaint {
  id: string;
  complaintNumber: string;
  userId: string;
  userName: string;
  userEmail: string;
  title: string;
  category: ComplaintCategory;
  description: string;
  location: string;
  department: Department;
  priority: Priority;
  status: ComplaintStatus;
  attachmentUrl?: string;
  adminRemarks?: string;
  resolutionDetails?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ComplaintHistory {
  id: string;
  complaintId: string;
  previousStatus: string;
  newStatus: string;
  remarks: string;
  changedBy: string;
  changedById: string;
  timestamp: string;
}
