import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { UserDashboard } from './components/UserDashboard';
import { ComplaintTrackingView } from './components/ComplaintTrackingView';
import { AdminDashboard } from './components/AdminDashboard';
import { ComplaintSubmissionModal } from './components/ComplaintSubmissionModal';
import { AuthModal } from './components/AuthModal';
import { submitComplaint } from './services/complaintService';
import { ShieldAlert, Sparkles, PlusCircle } from 'lucide-react';
import { BOOTSTRAP_ADMIN_EMAIL } from './firebase';

function MainApp() {
  const { currentUser, userProfile, isAdmin, loading } = useAuth();

  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [trackingNumber, setTrackingNumber] = useState<string>('');
  const [seeding, setSeeding] = useState(false);
  const [seedNotice, setSeedNotice] = useState<string | null>(null);

  const openAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleTrackWithNumber = (num: string) => {
    setTrackingNumber(num);
    setCurrentTab('track');
  };

  // Seed sample college complaints if desired for demonstration
  const handleSeedDemoData = async () => {
    if (!currentUser) {
      openAuth('login');
      return;
    }
    setSeeding(true);
    setSeedNotice(null);
    try {
      const demoComplaints = [
        {
          userId: currentUser.uid,
          userName: userProfile?.fullName || currentUser.displayName || 'Demo Student',
          userEmail: currentUser.email || 'student@college.edu',
          title: 'AC unit malfunctioning in Main Seminar Hall',
          category: 'Electricity' as const,
          description: 'The split AC on the left wing of Seminar Hall 2 is making a buzzing sound and not cooling properly.',
          location: 'Seminar Hall 2, Academic Block A',
          department: 'Electrical Department' as const,
          priority: 'High' as const,
        },
        {
          userId: currentUser.uid,
          userName: userProfile?.fullName || currentUser.displayName || 'Demo Student',
          userEmail: currentUser.email || 'student@college.edu',
          title: 'Water filter leaking and low pressure in 3rd Floor Cafeteria',
          category: 'Water Supply' as const,
          description: 'Continuous water leakage from RO purification unit near the dining hall causing slippery floor.',
          location: 'Central Cafeteria, Floor 3',
          department: 'Water and Sanitation Department' as const,
          priority: 'Medium' as const,
        },
        {
          userId: currentUser.uid,
          userName: userProfile?.fullName || currentUser.displayName || 'Demo Student',
          userEmail: currentUser.email || 'student@college.edu',
          title: 'Wi-Fi router down in Central Computer Laboratory 4',
          category: 'Technical Issues' as const,
          description: 'All 35 workstations lost connection to campus LAN and internet gateway during database lab session.',
          location: 'IT Lab 4, Tech Building',
          department: 'IT Support Department' as const,
          priority: 'High' as const,
        },
        {
          userId: currentUser.uid,
          userName: userProfile?.fullName || currentUser.displayName || 'Demo Student',
          userEmail: currentUser.email || 'student@college.edu',
          title: 'Broken desk benches in Room 102',
          category: 'Infrastructure' as const,
          description: 'Two front-row wooden study desks have damaged frames needing carpenter repair.',
          location: 'Lecture Hall 102, Ground Floor',
          department: 'Infrastructure Department' as const,
          priority: 'Low' as const,
        },
      ];

      for (const item of demoComplaints) {
        await submitComplaint(item);
      }
      setSeedNotice('Successfully generated 4 demo complaints across departments!');
      setTimeout(() => setSeedNotice(null), 5000);
    } catch (e: any) {
      console.error('Demo seeding notice:', e);
      setSeedNotice('Failed to create demo entries: ' + (e.message || 'Error'));
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Top Demo Bar / Project Helper */}
      <div className="bg-blue-900 text-blue-100 text-xs px-4 py-2 border-b border-blue-800 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-blue-300" />
          <span className="font-semibold text-white">Admin Access:</span>
          <span>
            Sign in as <strong className="text-white">{BOOTSTRAP_ADMIN_EMAIL}</strong> for Admin privileges.
          </span>
        </div>
        <div className="flex items-center gap-2">
          {currentUser && (
            <button
              onClick={handleSeedDemoData}
              disabled={seeding}
              className="px-2.5 py-0.5 rounded bg-blue-800 hover:bg-blue-700 text-white text-[11px] font-semibold transition border border-blue-600 disabled:opacity-50"
            >
              {seeding ? 'Populating...' : '+ Seed 4 Demo Complaints'}
            </button>
          )}
        </div>
      </div>

      {seedNotice && (
        <div className="bg-emerald-600 text-white text-xs px-4 py-1.5 text-center font-bold">
          {seedNotice}
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openAuthModal={openAuth}
        openSubmitModal={() => setIsSubmitModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'landing' && (
          <LandingPage
            onNavigateTab={setCurrentTab}
            openSubmitModal={() => {
              if (!currentUser) openAuth('login');
              else setIsSubmitModalOpen(true);
            }}
            openAuthModal={openAuth}
            onTrackWithNumber={handleTrackWithNumber}
          />
        )}

        {currentTab === 'dashboard' && (
          currentUser ? (
            <UserDashboard
              onOpenSubmit={() => setIsSubmitModalOpen(true)}
              onTrackComplaint={handleTrackWithNumber}
            />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-2xl shadow-md border border-slate-200 text-center space-y-4">
              <ShieldAlert className="w-12 h-12 text-blue-600 mx-auto" />
              <h2 className="text-lg font-bold text-slate-900">Sign In Required</h2>
              <p className="text-xs text-slate-600">
                Please log in to your account to view your personal complaints dashboard.
              </p>
              <button
                onClick={() => openAuth('login')}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs transition"
              >
                Log In to Continue
              </button>
            </div>
          )
        )}

        {currentTab === 'track' && (
          <ComplaintTrackingView
            initialComplaintNumber={trackingNumber}
            onOpenSubmit={() => {
              if (!currentUser) openAuth('login');
              else setIsSubmitModalOpen(true);
            }}
          />
        )}

        {currentTab === 'admin' && (
          currentUser && isAdmin ? (
            <AdminDashboard onTrackComplaint={handleTrackWithNumber} />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-2xl shadow-md border border-slate-200 text-center space-y-4">
              <ShieldAlert className="w-12 h-12 text-rose-600 mx-auto" />
              <h2 className="text-lg font-bold text-slate-900">Administrator Access Restricted</h2>
              <p className="text-xs text-slate-600">
                You must be authenticated as an authorized administrator ({BOOTSTRAP_ADMIN_EMAIL}) to access the administrative command console.
              </p>
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => openAuth('login')}
                  className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs transition"
                >
                  Sign In with Admin Account
                </button>
                <button
                  onClick={() => setCurrentTab('landing')}
                  className="w-full py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs transition font-semibold"
                >
                  Back to Home
                </button>
              </div>
            </div>
          )
        )}
      </main>

      {/* Complaint Submission Dialog */}
      <ComplaintSubmissionModal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        onSuccessComplaint={(c) => {
          setTrackingNumber(c.complaintNumber);
        }}
      />

      {/* Auth Dialog */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authMode}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
