# Digital Complaint Management System (DCMS)

A full-stack, cloud-connected grievance redressal web application designed for college project demonstrations and institutional issue tracking.

---

## 🌟 Key Features

1. **User Authentication & Role-Based Access Control (RBAC)**:
   - Integrated with **Firebase Authentication** (One-click Google Sign-In and Email/Password).
   - Secure server-verified roles: Regular Users (Students/Citizens) vs. Administrators.
   - Bootstrapped Administrator privileges for `balagamnaveen925@gmail.com`.
2. **Online Complaint Lodging**:
   - Unique Complaint ID generation (e.g. `CMP-2026-48201`).
   - 8 Standardized Categories: *Infrastructure, Electricity, Water Supply, Sanitation, Technical Issues, Safety & Security, Public Services, Other*.
   - 6 Specialized Campus Departments:
     - *Infrastructure Department*
     - *Electrical Department*
     - *Water and Sanitation Department*
     - *IT Support Department*
     - *Security Department*
     - *General Administration*
   - Priority classification (*Low, Medium, High*).
   - Validated photo attachment upload (image formats up to 2MB).
3. **Real-Time Complaint Tracking & Audit History**:
   - Public and private lookup by Complaint ID or Document ID.
   - Live visual status stepper: **Submitted → Pending → In Progress → Resolved** (or **Rejected**).
   - Immutable audit trail recording state changes, timestamp, and administrator remarks.
4. **Institutional Administrator Console**:
   - Live statistics calculated directly from Cloud Firestore records.
   - Interactive visual analytics charts (*Recharts*): Status Breakdown (Donut Chart) and Category Distribution (Bar Chart).
   - Search, multi-filtering (by status, department, category, priority), and sorting.
   - Department assignment/re-routing and status progression controls.
   - Single-click CSV export for official reports.
   - Safe complaint deletion with double confirmation.

---

## 🏗️ Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide React icons, Recharts.
- **Backend & Database**: Cloud Firestore (Enterprise edition via Google AI Studio).
- **Authentication**: Firebase Authentication.
- **Security Rules**: Declarative Attribute-Based Access Control (ABAC) in `firestore.rules`.

---

## 📁 Database Schema (Cloud Firestore)

### 1. `users/{userId}`
- `userId`: string (Firebase Auth UID)
- `fullName`: string
- `email`: string
- `role`: `"user"` | `"admin"`
- `createdAt`: ISO timestamp string

### 2. `admins/{adminId}`
- `userId`: string (Firebase Auth UID)
- `email`: string
- `role`: `"admin"`
- `createdAt`: ISO timestamp string

### 3. `complaints/{complaintId}`
- `complaintNumber`: string (e.g. `CMP-2026-92812`)
- `userId`: string (author UID)
- `userName`: string
- `userEmail`: string
- `title`: string
- `category`: Category string
- `description`: string
- `location`: string
- `department`: Department string
- `priority`: `"Low"` | `"Medium"` | `"High"`
- `status`: `"Submitted"` | `"Pending"` | `"In Progress"` | `"Resolved"` | `"Rejected"`
- `attachmentUrl`: optional image base64 data URL
- `adminRemarks`: string
- `resolutionDetails`: string
- `createdAt`: ISO timestamp string
- `updatedAt`: ISO timestamp string

### 4. `complaints/{complaintId}/history/{historyId}` (Subcollection)
- `id`: string
- `complaintId`: string
- `previousStatus`: string
- `newStatus`: string
- `remarks`: string
- `changedBy`: string
- `changedById`: string
- `timestamp`: ISO timestamp string

---

## 🚀 How to Run the Project Locally

### 1. Prerequisites
- Node.js (version 18 or higher)
- npm or bun

### 2. Install Dependencies
```bash
npm install
```

### 3. Start Development Server
```bash
npm run dev
```

### 4. Open in Browser
Open [http://localhost:3000](http://localhost:3000) (or the port specified by Vite in terminal output).

---

## 🔐 Administrator Configuration

1. **Automatic Bootstrapping**:
   - The user email `balagamnaveen925@gmail.com` is configured as the Primary Administrator in `src/firebase.ts`, `src/context/AuthContext.tsx`, and `firestore.rules`.
   - When you log in with this email, the app immediately grants you Administrator rights and loads the **Admin Portal**.

2. **Promoting Additional Administrators in Firestore**:
   - Open your Firebase Console: [https://console.firebase.google.com](https://console.firebase.google.com)
   - Navigate to **Firestore Database** → collection `admins`.
   - Add a document where the Document ID is the target user's Firebase Auth UID with fields:
     ```json
     {
       "userId": "<USER_UID>",
       "email": "admin@college.edu",
       "role": "admin",
       "createdAt": "2026-10-11T00:00:00.000Z"
     }
     ```

---

## 🧪 College Project Evaluation & Demo Script

Follow these steps during your project viva or demonstration:

1. **Step 1: Landing Page Overview**
   - Show the project title, 3-step workflow (Submit, Track, Resolve), and key benefits.
2. **Step 2: User Complaint Lodging**
   - Click **Submit Complaint**.
   - Fill in:
     - Title: `Water leakage in Chemistry Laboratory Room 302`
     - Category: `Water Supply` (notice how the system auto-assigns *Water and Sanitation Department*)
     - Location: `Science Block C, 3rd Floor`
     - Priority: `High`
     - Upload a sample picture.
   - Click **Submit Complaint**.
   - Copy the generated `CMP-2026-XXXXX` tracking ID.
3. **Step 3: User Dashboard**
   - Open **My Dashboard** to show live dynamic statistics and the recent complaints table.
4. **Step 4: Status Tracking**
   - Open **Track Status** and paste the Complaint ID.
   - Review the progress stepper and initial audit history entry.
5. **Step 5: Administrator Actions**
   - Click **Admin Portal** in the navigation bar.
   - Show the 6 metric cards and real-time **Recharts** charts (Status breakdown & Category distribution).
   - Search or filter the complaint.
   - Click **Review / Update**.
   - Change Status from `Submitted` to `In Progress`.
   - Add remarks: `Plumber technician dispatched to replace faulty pipe.`
   - Click **Save & Update Database**.
   - Show how the tracking timeline instantly updates!
6. **Step 6: CSV Export**
   - Click **Export CSV Report** to download the formatted audit spreadsheet.
