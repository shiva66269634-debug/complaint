# Security Specification: Digital Complaint Management System

## 1. Data Invariants

1. **User Identity Isolation**: A user can only create or update their own user profile document at `/users/{userId}` where `userId == request.auth.uid`.
2. **Admin Privilege Protection**: Regular users cannot write to the `/admins` collection or self-assign the `admin` role.
3. **Complaint Ownership & Submission**:
   - Only authenticated users can submit complaints (`request.auth != null`).
   - The `userId` of the complaint must match `request.auth.uid`.
   - The initial status must be `"Submitted"`.
4. **Complaint Lifecycle & Role Gates**:
   - Regular users can read their own complaints (`resource.data.userId == request.auth.uid`).
   - Authenticated administrators (`isAdmin()`) can read, assign departments, add remarks, update status, and enter resolution details on all complaints.
   - For public status lookup, complaint records can only be queried by their unique ID or complaint number, revealing necessary tracking progress without exposing unauthorized writes.
5. **Audit History Immutability**:
   - Audit history entries in `/complaints/{complaintId}/history/{historyId}` are append-only.
   - History entries can only be written by authenticated users (for initial creation) or admins (for status changes), and cannot be modified or deleted once created.
6. **Deletion Protection**:
   - Complaints can only be deleted by verified administrators.

## 2. The "Dirty Dozen" Threat Payloads

1. **Payload 1: Impersonated Author Injection**
   - Attempting to submit a complaint with `userId: "attacker_victim_uid"` while authenticated as `user_123`.
   - Expected Result: `PERMISSION_DENIED`.

2. **Payload 2: Self-Promotion to Admin**
   - Attempting to write a document to `/admins/{user_uid}` with `{ "role": "admin" }` as an unprivileged user.
   - Expected Result: `PERMISSION_DENIED`.

3. **Payload 3: Direct User Profile Elevation**
   - Modifying own user record at `/users/{uid}` to inject `{ "role": "admin" }`.
   - Expected Result: `PERMISSION_DENIED`.

4. **Payload 4: Status Bypass on Creation**
   - Submitting a complaint with `status: "Resolved"` directly on create.
   - Expected Result: `PERMISSION_DENIED`.

5. **Payload 5: Unauthorized Complaint Editing by Peer**
   - User B attempting to edit or delete User A's complaint.
   - Expected Result: `PERMISSION_DENIED`.

6. **Payload 6: Ghost Field Injection (Shadow Update)**
   - Updating a complaint with arbitrary unauthorized fields like `{ "isBypassed": true }`.
   - Expected Result: `PERMISSION_DENIED`.

7. **Payload 7: Unauthenticated Complaint Submission**
   - Writing to `/complaints/{id}` with unauthenticated `request.auth == null`.
   - Expected Result: `PERMISSION_DENIED`.

8. **Payload 8: Non-Admin Status Mutation**
   - A regular user attempting to change complaint status from "Submitted" to "Resolved".
   - Expected Result: `PERMISSION_DENIED`.

9. **Payload 9: Audit History Tampering**
   - Attempting to update or delete a log entry in `/complaints/{complaintId}/history/{historyId}`.
   - Expected Result: `PERMISSION_DENIED`.

10. **Payload 10: Oversized Payload Attack (Denial of Wallet)**
    - Submitting a complaint title of 20,000 characters or description of 500,000 characters.
    - Expected Result: `PERMISSION_DENIED`.

11. **Payload 11: Non-Admin Complaint Deletion**
    - A standard user attempting to delete any complaint from `/complaints/{id}`.
    - Expected Result: `PERMISSION_DENIED`.

12. **Payload 12: Admin Spoofing via Unverified Claims**
    - Attempting admin write operations when not listed in the `/admins` collection or verified admin email.
    - Expected Result: `PERMISSION_DENIED`.
